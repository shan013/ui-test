//---------  scrollToFixed ------//

jQuery(document).ready(function () {

    jQuery('.header').scrollToFixed();
});

//-----------scroll-to-fix---------//
function resizeHeaderOnScroll() {
    const distanceY = window.pageYOffset || document.documentElement.scrollTop,
        shrinkOn = 50,
        headerEl = document.getElementById('resizeHead');

    if (distanceY > shrinkOn) {
        headerEl.classList.add("header-smaller");
    } else {
        headerEl.classList.remove("header-smaller");
    }
}

window.addEventListener('scroll', resizeHeaderOnScroll);

//slick slider
$('.slider-intro').slick({
    dots: false,
    infinite: true,
    autoplay: true,
    arrows: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    prevArrow: "<button class='prev-btn'><i class='fa-solid fa-chevron-left'></i></button>",
    nextArrow: "<button class='next-btn'><i class='fa-solid fa-chevron-right'></i></button>",
});

//hamberger menu animation
$(document).ready(function () {
    $(".navbar-toggler").click(function () {
        $(this).toggleClass("is-active");
    });
});

//---------------Menu Toggle---------------------//
jQuery(window).load(function () {
    var screenW = jQuery(window).width();
    if (screenW < 1200) {
        if (jQuery('.navbar-collapse .sub-menu').length) {
            jQuery('sub-menu').each(function () {
                //jQuery(this).siblings('a').clone().prependTo(this).wrap('<li />');
                //jQuery(this).siblings('a').removeAttr("href");
            });
            jQuery('.navbar-collapse ul li a').on('click', function () {
                jQuery(this).parent().children('.sub-menu').slideToggle('100');
                if (jQuery(this).hasClass('active')) {
                    jQuery(this).removeClass('active');
                } else {
                    jQuery(this).addClass('active');
                }
                return true;
            });

        };
    }
});

//-----------------aos-animation-------------------//
$(function () {
    AOS.init();
});

$(window).on('load', function () {
    AOS.refresh();
});


//----------text-count-animation----------
$('.counter-count').each(function () {
    $(this).prop('Counter', 0).animate({
        Counter: $(this).text()
    }, {
        duration: 6000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
});
